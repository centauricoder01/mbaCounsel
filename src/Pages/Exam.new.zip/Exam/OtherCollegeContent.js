import React from 'react'
import "./AllCollegeInExam.css"

const OtherCollegeContent = () => {
  return (
   


  <div className="other-cards-body" >
  <img src={require("../../Assets/exam-page-christ-university-other-number-1.png")} alt="" width={200} />
    <h6 style={ {textAlign:"center" }}>Christ University
Bangalore</h6>
  </div>

    
    
  )
}

export default OtherCollegeContent
